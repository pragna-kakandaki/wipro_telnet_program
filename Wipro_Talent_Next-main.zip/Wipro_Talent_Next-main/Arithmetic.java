// Write a program to demonstrate working of arithmetic operators.
public class Arithmetic {
    public static void main(String[] args) {
        int a = 10, b = 5;
        System.out.println("addition:"+ (a + b)+
                           "\nsubtraction:" + (a - b) +
                           "\nmultiplication:" + (a * b) +
                           "\ndivision:" + (a / b) +
                           "\nmodulus:" + (a % b));
        
    }
}