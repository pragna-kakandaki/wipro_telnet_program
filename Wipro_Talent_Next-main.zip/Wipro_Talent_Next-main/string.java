// program to demonstrate string is a datatype or class in Java
public class string {
    public static void main(String[] args) {
        // String is a class in Java
        String str = "Hello, World!";
        
        // Display the string
        System.out.println("String: " + str);
        
        // Display the length of the string
        System.out.println("Length of the string: " + str.length());
        
        
    }
}